# Fresh Data - Hello World

This is the simplest example possible using Fresh Data. It adds a locally implemented API to fetch data to be presented in a React component.

This example project was built with [Create React App](https://github.com/facebookincubator/create-react-app).

## Try it out!
--------------
Simply run:

```npm start```
