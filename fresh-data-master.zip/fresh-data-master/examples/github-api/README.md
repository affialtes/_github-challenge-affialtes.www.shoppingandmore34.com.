# Fresh Data Example - GitHub REST API

This example code shows how to use data from public GitHub API calls.

This example project was built with [Create React App](https://github.com/facebook/create-react-app).

## Try it out!
--------------
Simply run:

```npm start```
